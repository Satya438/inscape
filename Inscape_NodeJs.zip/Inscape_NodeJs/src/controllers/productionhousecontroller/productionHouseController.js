const AWS = require("aws-sdk");
const awsConfig = require("../../config");
AWS.config.update(awsConfig);

const { v4: uuidv4 } = require("uuid");

const ProductionHouseDetails = require("../../models/productionHouseModels");

// create project
const createProductionHouseDetails = (req, res) => {
  const { prodHouseName, prodHouseAddress, email } = req.body;
  // Ensure all required values are present
  if (!prodHouseName || !prodHouseAddress || !email) {
    return res.status(400).json({ error: "Missing required fields" });
  }
  const payloadData = {
    prodHouseName,
    prodHouseAddress,
    email,
  };

  ProductionHouseDetails.createProductionHouse(payloadData, (err, payload) => {
    if (err) {
      console.error("Error creating payload:", err);
      if (err.message === "Email not registered") {
        return res.status(400).json({ error: "Email not registered" });
      }
      return res
        .status(500)
        .json({ error: "Failed to create production house" });
    }
    if (payload) {
      console.log("Successfully created production house:", payload);
      return res
        .status(200)
        .json({ message: "Production house created successfully" });
    }
  });
};

const editProductionHouseDetails = (req, res) => {
  const { productionHouseId, prodHouseName, prodHouseAddress, email } =
    req.body;

  // Ensure all required values are present
  if (!productionHouseId || !prodHouseName || !prodHouseAddress || !email) {
    return res.status(400).json({ error: "Missing required fields" });
  }

  const payloadData = {
    productionHouseId,
    prodHouseName,
    prodHouseAddress,
    email,
  };

  ProductionHouseDetails.updateProductionHouse(
    payloadData,
    productionHouseId,
    (err, updatedItem) => {
      if (err) {
        console.error("Error updating production house:", err);
        if (err.message === "Email not registered") {
          return res.status(400).json({ error: "Email not registered" });
        }
        return res
          .status(500)
          .json({ error: "Failed to update production house" });
      }

      if (updatedItem) {
        console.log("Successfully updated production house:", updatedItem);
        return res
          .status(200)
          .json({ message: "Production house updated successfully" });
      }
    }
  );
};

const getAllProductionHouseDetails = (req, res) => {
  const { email, productionHouseId } = req.body;

  ProductionHouseDetails.getAllProductionHouses(
    productionHouseId,
    email,
    (err, productionHouses) => {
      if (err) {
        console.error("Error retrieving production houses:", err);
        if (err.message === "Email not registered") {
          return res.status(400).json({ error: "Email not registered" });
        }
        return res
          .status(500)
          .json({ error: "Failed to retrieve production houses" });
      }

      console.log(
        "Successfully retrieved production houses:",
        productionHouses
      );
      return res.status(200).json(productionHouses);
    }
  );
};

const getAllProductionHouseDetailsByEmail = (req, res) => {
  const { email } = req.body;

  ProductionHouseDetails.getAllProductionHousesByEmail(
    email,
    (err, productionHouses) => {
      if (err) {
        console.error("Error retrieving production houses:", err);
        if (err.message === "Email not registered") {
          return res.status(400).json({ error: "Email not registered" });
        }
        return res
          .status(500)
          .json({ error: "Failed to retrieve production houses" });
      }

      console.log(
        "Successfully retrieved production houses:",
        productionHouses
      );
      return res.status(200).json(productionHouses);
    }
  );
};
module.exports = {
  createProductionHouseDetails,
  editProductionHouseDetails,
  getAllProductionHouseDetails,
  getAllProductionHouseDetailsByEmail,
};
