const nodemailer = require("nodemailer");
const docClient = require("../../service")
const config = require("../../config");

const sendotp = async (payloadData, res) => {
  let otp = Math.floor(10000 + Math.random() * 80000);
  const otpparams = {
    TableName: "nodeinscape_users",
    Key: {
      email: payloadData,
    },
    UpdateExpression: "SET #otpAttr = :otpValue,#status = :statusvalue",

    ExpressionAttributeNames: {
      "#otpAttr": "otp",
      "#status": "status",
    },
    ExpressionAttributeValues: {
      ":otpValue": otp,
      ":statusvalue": "N",
    },
  };

  try {
    await docClient.update(otpparams).promise();
    const transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 465,
      secure: true,
      requireTLS: true,
      auth: {
        user: config.email,
        pass: config.password,
      },
      debug: true,
    });

    const mailOptions = {
      from: "Inscape <inscapeapplication1@gmail.com>",
      to: payloadData,
      subject: "Inscape otp Verification",
      html: `<p> verification code for inscape ${otp} </p>`,
    };

    transporter.sendMail(mailOptions, function (error, info) {
      if (error) {
        res.json({
          message: "An error occured",
          error,
        });
      } else {
        console.log("Mail has  sent", info.response);

        res.json("Mail has sent Successfully");
      }
    });
  } catch (error) {
    console.log(error);
  }
};

module.exports = { sendotp };
