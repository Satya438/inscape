const docClient = require("../../service");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const validateToken = require("../../JwtAuthorization");
const loginuser = (req, res) => {
  var email = req.body.email;
  var password = req.body.password;

  const loginparams = {
    TableName: "nodeinscape_users",
    FilterExpression: "email = :email",
    ExpressionAttributeValues: {
      ":email": email,
    },
  };

  docClient.scan(loginparams, (err, data) => {
    if (err) {
      res.json({
        error: err,
      });
    } else if (data.Items.length > 0) {
      const user = data.Items[0];
      bcrypt.compare(password, user.password, (err, result) => {
        if (err) {
          res.json({
            error: err,
          });
        }
        if (user.status == "Y") {
          if (result) {
            var token = genrateToken(user);
            console.log(token + " token");
            // res.json(token);
            res.send({ message: "Login successful!", token });
          } else {
            res.json({
              message: "Incorrect password!",
            });
          }
        } else {
          res.json({
            message: "otp verification not yet done",
          });
        }
      });
    } else {
      res.json({
        message: "No user found!",
      });
    }
  });
};

const genrateToken = (user) => {
  const token = jwt.sign({ name: user.email }, process.env.AWS_SECRET, {
    expiresIn: "1h",
  });
  return token;
};

module.exports = { loginuser };
