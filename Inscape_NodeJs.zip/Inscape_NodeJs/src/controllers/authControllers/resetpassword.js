const AWS = require("aws-sdk");
const config = require("../../config");
AWS.config.update(config);
const bcrypt = require("bcrypt");

const docClient = new AWS.DynamoDB.DocumentClient();

const resetpassword = (req, res) => {
  bcrypt.hash(req.body.password, 10, function (err, hashedpass) {
    if (err) {
      res.json({
        error: err,
      });
    }
    const currentDate = new Date();
    const createdDate = currentDate.toISOString(); 
    const createdTime = currentDate.toTimeString().split(" ")[0];
    const { email } = req.body;
    const passwordparams = {
      TableName: "nodeinscape_users",
      Key: {
        email,
      },
    };
    try {
      docClient.get(passwordparams).promise();
      const putParams = {
        TableName: "nodeinscape_users",
        Key: {
          email: email,
        },
        UpdateExpression:
          "SET #passwordAttr = :passwordValue,#confirmpasswordAttr = :confirmpasswordValue,#createdDate = :createdDate,#createdTime = :createdTime",
        ExpressionAttributeNames: {
          "#passwordAttr": "password",
          "#confirmpasswordAttr": "confirmpassword",
          "#createdDate": "createdDate",
          "#createdTime": "createdTime",
        },
        ExpressionAttributeValues: {
          ":passwordValue": hashedpass,
          ":confirmpasswordValue": hashedpass,
          ":createdDate": createdDate,
          ":createdTime": createdTime,
        },
      };
      docClient.update(putParams).promise();
      res.status(200).json("password changed successfully");
    } catch (err) {
      console.log(err);
    }
  });
};

module.exports = { resetpassword };
