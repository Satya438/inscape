const ProjectModel = require("../models/projectModel");

// GET /projects
const getAllProjects = async (req, res) => {
  const { productionHouseId } = req.body;

  ProjectModel.getAllProjects(productionHouseId, (err, projects) => {
    if (err) {
      console.error("Error retrieving projects:", err);
      if (err.message === "Email not registered") {
        return res.status(400).json({ error: "Email not registered" });
      }
      return res.status(500).json({ error: "Failed to retrieve projects" });
    }

    console.log("Successfully retrieved projects:", projects);
    return res.status(200).json(projects);
  });
};

// POST /projects
const createProject = async (req, res) => {
  const { projectTitle, projectDescription, productionHouseId } = req.body;

  if (!projectTitle || !projectDescription || !productionHouseId) {
    return res.status(400).json({ error: "Missing required fields" });
  }

  const payloadData = {
    productionHouseId,
    projectTitle,
    projectDescription,
  };

  ProjectModel.createProject(payloadData, (err, payload) => {
    if (err) {
      console.error("Error creating payload:", err);
      return res.status(500).json({ error: "Failed to create project" });
    }
    if (payload) {
      console.log("Successfully created project:", payload);
      return res.status(200).json({ message: "Project created successfully" });
    }
  });
};

// GET /projects/:id
const getProjectById = async (req, res) => {
  const { id } = req.params;

  try {
    const project = await ProjectModel.getProjectById(id);

    if (project) {
      res.json(project);
    } else {
      res.status(404).json({ error: "Project not found" });
    }
  } catch (error) {
    console.error("Error getting project:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

// PUT /projects/:id
const updateProject = async (req, res) => {
  const { id } = req.params;
  const { projectTitle, projectDescription } = req.body;

  try {
    await ProjectModel.updateProject(id, projectTitle, projectDescription);
    res.json({ message: "Project updated successfully" });
  } catch (error) {
    console.error("Error updating project:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

// DELETE /projects/:id
const deleteProject = async (req, res) => {
  const { id } = req.params;

  try {
    await ProjectModel.deleteProject(id);
    res.json({ message: "Project deleted successfully" });
  } catch (error) {
    console.error("Error deleting project:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

module.exports = {
  getAllProjects,
  createProject,
  getProjectById,
  updateProject,
  deleteProject,
};
