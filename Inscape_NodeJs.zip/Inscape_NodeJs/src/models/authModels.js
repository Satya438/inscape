const AWS = require("aws-sdk");
const awsConfig = require("../config");

AWS.config.update(awsConfig);

const docClient = new AWS.DynamoDB.DocumentClient();

// Model method to store a payload in DynamoDB
const createRegister = async (payloadData, callback, res) => {
  const params = {
    TableName: "nodeinscape_users",
    Item: {
      email: payloadData.email,
      username: payloadData.username,
      password: payloadData.password,
      confirmpassword: payloadData.confirmpassword,
      otp: payloadData.otp,
    },
  };
  docClient.put(params, (err, data) => {
    if (err) {
      console.error("Error storing payload in DynamoDB:", err);
      return callback(err);
    }
    callback(null, payloadData);
  });
};

const verifyotp = async (email, enterotp, res) => {
  const otpparams = {
    TableName: "nodeinscape_users",
    Key: {
      email: email,
    },
  };

  try {
    const data = await docClient.get(otpparams).promise();
    const otpmail = data.Item.email;
    console.log(otpmail);
    const putParams = {
      TableName: "nodeinscape_users",
      Key: {
        email: email,
      },
      UpdateExpression: "SET #statusAttr = :statusValue",
      ExpressionAttributeNames: {
        "#statusAttr": "status",
      },
      ExpressionAttributeValues: {
        ":statusValue": enterotp == data.Item.otp ? "Y" : "N",
      },
    };

    await docClient.update(putParams).promise();
    res.json("Otp verified Sucessfully");
  } catch (error) {
    // console.error("Error retrieving OTP data:", error);
    res.status(400).json({ message: error });
  }
};

module.exports = {
  createRegister,
  verifyotp,
};
