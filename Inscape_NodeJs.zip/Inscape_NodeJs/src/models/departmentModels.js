
const { v4: uuidv4 } = require("uuid");
const docClient = require("../service")

// Function to check if the email exists
async function checkEmailExists(email) {
    const params = {
        TableName: "nodeinscape_users",
        FilterExpression: "email = :email",
        ExpressionAttributeValues: {
            ":email": email
        }
    };

    try {
        const data = await docClient.scan(params).promise();

        if (data.Items.length === 0) {
            throw new Error("Email not registered");
        }
    } catch (error) {
        throw error;
    }
}

// method to create production house and its address
const createDepartment = async (payloadData, callback) => {
    const currentDate = new Date();
    // Separate date
    const createdOn = currentDate.toISOString().slice(0, 10);

    // Separate time
    const createdTime = currentDate.toTimeString().slice(0, 8);

    try {
        await checkEmailExists(payloadData.email);

        const departmentId = uuidv4(); // Generate a UUID for the production house ID
        const params = {
            TableName: "nodeInscape_department",
            Item: {
                departmentId,
                departmentName: payloadData.departmentName,
                email: payloadData.email,
                createdOn: createdOn,
                createdTime: createdTime,
                createdBy: "inscape"
            }
        };

        docClient.put(params, (err, data) => {
            if (err) {
                console.error("Error storing payload in DynamoDB:", err);
                return callback(err);
            }
            callback(null, payloadData);
        });
    } catch (error) {
        callback(error, null);
    }
};

// method to get departments based on email
const getAllDepartmentsByEmail = async (email, callback) => {
    let params = {
        TableName: "nodeInscape_department",
        FilterExpression: "email=:email",
        ExpressionAttributeValues: {
            ":email": email,
        }
    };
    try {
        await checkEmailExists(email)
        docClient.scan(params, (err, data) => {
            if (err) {
                console.error("Error retrieving departments:", err)
            }
            const departments = data.Items
            return callback(err, departments)
        })
    } catch (error) {
        callback(error, null);
    }
}

// edit department by email 
const editDepartment = async (payload, callback) => {
    const currentDate = new Date();
    // Separate date
    const createdOn = currentDate.toISOString().slice(0, 10);

    // Separate time
    const createdTime = currentDate.toTimeString().slice(0, 8);

    try {
        await checkEmailExists(payload.email);
        const updateItem = {
            departmentName: payloadData.departmentName,
            email: payloadData.email,
            createdOn: createdOn,
            createdTime: createdTime,
            createdBy: "inscape"
        }

        const params = {
            TableName: "nodeInscape_department",
            Item: updateItem,
            ReturnValues: "ALL_OLD"
        }
        docClient.put(params, (err, data) => {
            if (err) {
                console.error("Error updating departments :", err)
                return callback(err, null)
            }
        })
    } catch (error) {
        callback(error, null);
    }
}
module.exports = {
    createDepartment,
    getAllDepartmentsByEmail,
    editDepartment
}