const express = require("express");
const validateToken = require("../JwtAuthorization");

const productionHouse = require("../controllers/productionhousecontroller/productionHouseController");
const router = express.Router();
router.use(validateToken);
router.route("/createproductionhouse").post(productionHouse.createProductionHouseDetails);
router.route("/editproductionhouse").put(productionHouse.editProductionHouseDetails);
router.route("/getproductionhouse").post(productionHouse.getAllProductionHouseDetails);
router.route("/getproductionhousebyemail").post(productionHouse.getAllProductionHouseDetailsByEmail);

module.exports = router