const jwt = require("jsonwebtoken");

const validateToken = (authorization, req, res, next) => {
  const authHeader = req.headers.authorization;

  if (authHeader) {
    try {
      const decoded = jwt.verify(authHeader, process.env.AWS_SECRET);
      req.user = decoded.user;
      next();
    } catch (error) {
      console.log("Error:", error);
      if (error.name === "TokenExpiredError") {
        res.status(401).send({ message: "Token has expired" });
      } else {
        res.status(401).send({ message: "Invalid token" });
      }
    }
  } else {
    res
      .status(401)
      .send({ message: "User is not authorized or token is missing" });
  }
};
module.exports = validateToken;
