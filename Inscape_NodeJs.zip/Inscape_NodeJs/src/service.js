const AWS = require("aws-sdk");
const awsConfig = require("./config");
AWS.config.update(awsConfig);
const docClient = new AWS.DynamoDB.DocumentClient();

module.exports = docClient;
