
const { v4: uuidv4 } = require("uuid");

const docClient = require("../service")
// Function to check if the email exists
async function checkEmailExists(email) {
  const params = {
    TableName: "nodeinscape_users",
    FilterExpression: "email = :email",
    ExpressionAttributeValues: {
      ":email": email,
    },
  };

  try {
    const data = await docClient.scan(params).promise();

    if (data.Items.length === 0) {
      throw new Error("Email not registered");
    }
  } catch (error) {
    throw error;
  }
}

// method to create production house and its address
const createProductionHouse = async (payloadData, callback) => {
  const currentDate = new Date();
  // Separate date
  const createdOn = currentDate.toISOString().slice(0, 10);

  // Separate time
  const createdTime = currentDate.toTimeString().slice(0, 8);

  try {
    await checkEmailExists(payloadData.email);

    const productionHouseId = uuidv4(); // Generate a UUID for the production house ID
    const params = {
      TableName: "nodeproductionhouse_details",
      Item: {
        productionHouseId,
        prodHouseName: payloadData.prodHouseName,
        prodHouseAddress: payloadData.prodHouseAddress,
        email: payloadData.email,
        createdOn: createdOn,
        createdTime: createdTime,
      },
    };

    docClient.put(params, (err, data) => {
      if (err) {
        console.error("Error storing payload in DynamoDB:", err);
        return callback(err);
      }
      callback(null, payloadData);
    });
  } catch (error) {
    callback(error, null);
  }
};

const updateProductionHouse = async (
  payloadData,
  productionHouseId,
  callback
) => {
  const currentDate = new Date();
  // Separate date
  const createdOn = currentDate.toISOString().slice(0, 10);

  // Separate time
  const createdTime = currentDate.toTimeString().slice(0, 8);

  try {
    await checkEmailExists(payloadData.email);

    const updatedItem = {
      prodHouseName: payloadData.prodHouseName,
      prodHouseAddress: payloadData.prodHouseAddress,
      email: payloadData.email,
      productionHouseId: payloadData.productionHouseId,
      createdOn: createdOn,
      createdTime: createdTime,
    };

    const params = {
      TableName: "nodeproductionhouse_details",
      Item: updatedItem,
      ReturnValues: "ALL_OLD",
    };

    docClient.put(params, (err, data) => {
      if (err) {
        console.error("Error updating production house:", err);
        return callback(err, null);
      }

      callback(null, updatedItem);
    });
  } catch (error) {
    callback(error, null);
  }
};

const getAllProductionHouses = async (productionHouseId, email, callback) => {
  let params = {
    TableName: "nodeproductionhouse_details",
    Key: { productionHouseId },
  };

  try {
    if (email) {
      await checkEmailExists(email);

      params = {
        ...params,
        FilterExpression: "email = :email",
        ExpressionAttributeValues: {
          ":email": email,
        },
      };
    }

    docClient.get(params, (err, data) => {
      if (err) {
        console.error("Error retrieving production houses:", err);
        return callback(err, null);
      }

      const productionHouses = data.Item;
      callback(null, productionHouses);
    });
  } catch (error) {
    callback(error, null);
  }
};

const getAllProductionHousesByEmail = async (email, callback) => {
  let params = {
    TableName: "nodeproductionhouse_details",
    FilterExpression: "email = :email",
    ExpressionAttributeValues: {
      ":email": email,
    },
  };

  try {
    await checkEmailExists(email);

    docClient.scan(params, (err, data) => {
      if (err) {
        console.error("Error retrieving production houses:", err);
        return callback(err, null);
      }
      const productionHouses = data.Items;
      callback(null, productionHouses);
    });
  } catch (error) {
    callback(error, null);
  }
};
module.exports = {
  createProductionHouse,
  updateProductionHouse,
  getAllProductionHouses,
  getAllProductionHousesByEmail,
};
