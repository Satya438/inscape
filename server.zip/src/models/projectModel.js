const AWS = require("aws-sdk");
const docClient = new AWS.DynamoDB.DocumentClient();
const { v4: uuidv4 } = require("uuid");

async function checkProductionHouse(productionHouseId) {
  const params = {
    TableName: "nodeproductionhouse_details",
    FilterExpression: "productionHouseId = :productionHouseId",
    ExpressionAttributeValues: {
      ":productionHouseId": productionHouseId,
    },
  };

  try {
    const data = await docClient.scan(params).promise();

    if (data.Items.length === 0) {
      throw new Error("Email not registered");
    }
  } catch (error) {
    throw error;
  }
}

const getAllProjects = async (productionHouseId, callback) => {
  let params = {
    TableName: "nodeinscape_projects",
    ExpressionAttributeValues: {},
  };

  try {
    if (productionHouseId) {
      await checkProductionHouse(productionHouseId);

      params = {
        ...params,
        FilterExpression: "productionHouseId = :productionHouseId",
        ExpressionAttributeValues: {
          ":productionHouseId": productionHouseId,
        },
      };
    }

    docClient.scan(params, (err, data) => {
      if (err) {
        console.error("Error retrieving projects:", err);
        return callback(err, null);
      }

      const projects = data.Items;
      callback(null, projects);
    });
  } catch (error) {
    callback(error, null);
  }
};

const createProject = async (payloadData, callback) => {
  try {
    await checkProductionHouse(payloadData.productionHouseId);

    const projectId = uuidv4(); // Generate a UUID for the production house ID
    const { projectTitle, projectDescription, productionHouseId } = payloadData; // Destructure the payloadData object

    const params = {
      TableName: "nodeinscape_projects",
      Item: {
        projectId: projectId,
        projectTitle: projectTitle,
        projectDescription: projectDescription,
        productionHouseId: productionHouseId,
      },
    };

    docClient.put(params, (err, data) => {
      if (err) {
        console.error("Error storing payload in DynamoDB:", err);
        return callback(err);
      }
      callback(null, payloadData);
    });
  } catch (error) {
    callback(error, null);
  }
};

const getProjectById = async (projectId) => {
  const params = {
    TableName: "nodeinscape_projects",
    Key: {
      projectId: projectId,
    },
  };

  try {
    const result = await docClient.get(params).promise();
    return result.Item;
  } catch (error) {
    console.error("Error getting project:", error);
    return null;
  }
};

const updateProject = async (projectId, projectTitle, projectDescription) => {
  const params = {
    TableName: "nodeinscape_projects",
    Key: {
      projectId: projectId,
    },
    UpdateExpression: "set #n = :projectTitle, #d = :projectDescription",
    ExpressionAttributeNames: {
      "#n": "projectTitle",
      "#d": "projectDescription",
    },
    ExpressionAttributeValues: {
      ":projectTitle": projectTitle,
      ":projectDescription": projectDescription,
    },
  };

  try {
    await docClient.update(params).promise();
    console.log("Project updated successfully");
  } catch (error) {
    console.error("Error updating project:", error);
    throw error;
  }
};

const deleteProject = async (projectId) => {
  const params = {
    TableName: "nodeinscape_projects",
    Key: {
      projectId: projectId,
    },
  };

  try {
    await docClient.delete(params).promise();
    console.log("Project deleted successfully");
  } catch (error) {
    console.error("Error deleting project:", error);
    throw error;
  }
};

module.exports = {
  getAllProjects,
  createProject,
  getProjectById,
  updateProject,
  deleteProject,
};
