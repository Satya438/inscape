const Register = require("../../models/authModels");
const bcrypt = require("bcrypt");
const send = require("../authControllers/sendotp");
const docClient = require("../../service");

const registerUser = (req, res) => {
  bcrypt.hash(req.body.password, 10, function (err, hashedpass) {
    if (err) {
      res.json({
        error: err,
      });
    }

    const { email, username } = req.body;
    // Ensure all required values are present
    if (!email || !username) {
      return res.status(400).json({ error: "Missing required fields" });
    }
    // let otp = Math.floor(10000 + Math.random() * 80000);

    const payloadData = {
      email,
      username,
      password: hashedpass,
      confirmpassword: hashedpass,
    };

    const mailvalidate = {
      TableName: "nodeinscape_users",

      Key: {
        email: payloadData.email,
      },
    };

    try {
      docClient.get(mailvalidate, async (error, data) => {
        if (error) {
          console.error("Error retrieving user:", error);

          res.status(500);

          throw new Error("Failed to retrieve user");
        }
        console.log(data);

        if (data.Item) {
          return res.status(400).send("User already registered!");
        }

        const payload = await new Promise((resolve, reject) => {
          Register.createRegister(payloadData, (err, payload) => {
            if (err) {
              console.error("Error creating payload:", err);
              reject(err);
            } else {
              resolve(payload);
            }
          });
        });

        await send.sendotp(payloadData.email, res, payload);
      });
    } catch (error) {
      console.log(error);
    }
  });
};

const verifyotp = (req, res) => {
  const { email, enterotp } = req.body;
  Register.verifyotp(email, enterotp, res);
};

module.exports = { registerUser, verifyotp };
