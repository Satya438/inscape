const nodemailer = require("nodemailer");
const config = require("../../config");
const AWS = require("aws-sdk");
const { sendotp } = require("./sendotp");

AWS.config.update(config);
const docClient = new AWS.DynamoDB.DocumentClient();

const forgotpassword = async (req, res) => {
  const { email } = req.body;
  if (!email) {
    res.send("please enter mail");
  } else {
    const passwordparams = {
      TableName: "nodeinscape_users",
      Key: {
        email,
      },
    };
    try {
      const data = await docClient.get(passwordparams).promise();
      if (email == data.Item.email && data.Item.status == "Y") {
        sendotp(email, res);
      } else {
        res.json({ error: "Mail not register with us" });
      }
    } catch (error) {
      if (error.code === "ValidationException") {
        res.json("ValidationException:", error.message);
        // Handle the validation error appropriately
        // Send an error response to the client, or perform other error handling steps
      } else {
        // Handle other types of errors
        console.log("Error:", error);
      }
    }
  }
};

module.exports = { forgotpassword };
