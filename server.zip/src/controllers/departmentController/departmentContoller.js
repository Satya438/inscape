const AWS = require("aws-sdk")
const awsConfig = require("../../config")
AWS.config.update(awsConfig)

const departmentDetails = require("../../models/departmentModels")

// create department
const createDepartmentDetails = (req, res) => {
    const { departmentName, email } = req.body
    // Ensure all required values are present
    if (!departmentName || !email) {
        return res.status(400).json({ error: "Missing required fields" })
    }
    const payloadData = {
        departmentName,
        email
    }
    departmentDetails.createDepartment(payloadData, (err, payload) => {
        if (err) {
            console.error('Error in creating the Department', err);
            if (err.message === "Email not registered") {
                return res.status(400).json({ error: "Email not registered" });
            }
            return res.status(400).json({
                error: 'Error in creating the Department', err
            })
        }
        if (payload) {
            console.log("Successfully created production house:", payload)
            return res
                .status(200)
                .json({ message: "Production house created successfully" });
        }
    })
}

// get departments by email
const getAllDepartmentDetailsByEmail = (req, res) => {
    const { email } = req.body
    departmentDetails.getAllDepartmentsByEmail(email, (err, department) => {
        if (err) {
            console.error("Error retrieving departments :", err)
            if (err.message === "Email not registered") {
                return res.status(400).json({ error: "Email not registered" });
            }
            return res
                .status(500)
                .json({ error: "Failed to retrieve departments" });
        }
        console.log("Successfully retrieved departments :", department)
        return res.status(200).json(department)
    })
}

// edit departments by email
const editDepartmentsDetails = (req, res) => {
    const { departmentName, email } = req.body

    // Ensure all required values are present
    if (!departmentName || !email) {
        return res.status(400).json({ error: "Missing required fields" });
    }
    const payloadData = {
        departmentName,
        email,
    };
    departmentDetails.editDepartment(payloadData, email, (err, updatedItem) => {
        if (!err) {
            console.error("Error updating department:", err)
            if (err.message === "Email not registered") {
                return res.status(400).json({ error: "Email not registered" });
            }
            return res
                .status(500)
                .json({ error: "Failed to update department" });
        }
        if (updatedItem) {
            console.log("Successfully updated department:", updatedItem);
            return res
                .status(200)
                .json({ message: "department updated successfully" });
        }
    })
}
module.exports = {
    createDepartmentDetails,
    getAllDepartmentDetailsByEmail,
    editDepartmentsDetails
}