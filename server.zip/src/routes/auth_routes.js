const express = require("express");
const forgotpasswordcontroller = require("../controllers/authControllers/forgotpassword");
const resetpasswordcontroller = require("../controllers/authControllers/resetpassword");
const registerController = require("../controllers/authControllers/registeruser");
const logincontroller = require("../controllers/authControllers/loginuser");

const router = express.Router();

// Route to store a payload
router.post("/register", registerController.registerUser);
router.post("/verify", registerController.verifyotp);
router.post("/forgotpassword", forgotpasswordcontroller.forgotpassword);
router.post("/resetpassword", resetpasswordcontroller.resetpassword);
router.post("/login", logincontroller.loginuser);
module.exports = router;
