const express = require("express");
const validateToken = require("../JwtAuthorization");

const departments = require("../controllers/departmentController/departmentContoller");
const router = express.Router();
router.use(validateToken);
router.route("/createdepartment").post(departments.createDepartmentDetails);
router.route("/getalldepartmentsbyemail").post(departments.getAllDepartmentDetailsByEmail);
router.route("/editdepartment").post(departments.editDepartmentsDetails);
module.exports = router