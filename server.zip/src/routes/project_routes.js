const express = require("express");
const validateToken = require("../JwtAuthorization");

const projectController = require("../controllers/projectController");
const router = express.Router();
router.use(validateToken);
router.route("/getallproject").post(projectController.getAllProjects);
router.route("/createproject").post(projectController.createProject);
router.route("/getproject/:id").get(projectController.getProjectById);
router.route("/update/:id").put(projectController.updateProject);
router.route("/delete/:id").delete(projectController.deleteProject);

module.exports = router;
